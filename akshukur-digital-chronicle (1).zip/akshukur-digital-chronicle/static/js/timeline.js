// Таймлайн сүзгісі main.js ішінде (.search[data-filter]) орындалады.
